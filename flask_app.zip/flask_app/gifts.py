from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

from app import db, Gift

# Создаем новые подарки
gift1 = Gift(name="Teddy Bear", cost=20, status="Available")
gift2 = Gift(name="Chocolate", cost=5, status="Sold Out")
# Добавляем подарки в базу данных
db.session.add(gift1)
db.session.add(gift2)
db.session.commit()  # Сохраняем изменения

gifts = Gift.query.all()  # Получаем все подарки из базы
print(gifts)