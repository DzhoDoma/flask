from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///gifts.db'
db = SQLAlchemy(app)

# Модель для подарков
class Gift(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    gift_name = db.Column(db.String(100), nullable=False)
    cost = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f"Gift('{self.full_name}', '{self.gift_name}', '{self.cost}', '{self.status}')"

@app.route('/')
def index():
    gifts = Gift.query.all()  # Получаем все подарки из базы
    return render_template('index.html', gifts=gifts)

@app.route('/add', methods=['POST'])
def add_gift():
    full_name = request.form['full_name']
    gift_name = request.form['gift_name']
    cost = request.form['cost']
    status = request.form['status']

    new_gift = Gift(full_name=full_name, gift_name=gift_name, cost=cost, status=status)
    db.session.add(new_gift)
    db.session.commit()  # Сохраняем изменения

    return redirect(url_for('index'))  # Перенаправляем обратно на главную страницу

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Создание таблиц, если их еще нет
    app.run(debug=True)


'''from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

class Gift(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    cost = db.Column(db.Integer, nullable=False)
    status = db.Column(db.String(10), nullable=False)

    def __repr__(self):
        return f"Gift('{self.name}', '{self.cost}', '{self.status}')"

@app.route('/')
def index():
    gifts = Gift.query.all()
    return render_template('index.html', gifts=gifts)

if __name__ == '__main__':
    with app.app_context():  # Устанавливаем контекст приложения
        db.create_all()  # Создание базы данных и таблиц
    app.run(debug=True)'''